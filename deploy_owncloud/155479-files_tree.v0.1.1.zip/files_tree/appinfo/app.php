<?php
OCP\Util::addscript( 'files_tree', 'tree');
OCP\Util::addStyle('files_tree', 'files_tree');