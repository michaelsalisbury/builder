<?php  
$currentdir=$_REQUEST['dir'];
$uid=OCP\User::getUser();
$dirs_stat = OC_Preferences::getValue($uid,'files_tree','dirs_stat','');
if($dirs_stat=='') $dirs_stat=array();
else $dirs_stat=unserialize($dirs_stat);


function listdir($dir,$dirs_stat){
	//print_r($keys);
	//$dirs_stat = OC_Appconfig::getValue('files_tree', 'dirs_stat','');
	$list = OC_Files::getdirectorycontent($dir);
	if(sizeof($list)>0){
		$ret='';
		$d=explode('/',$dir);
		foreach( $list as $i ) {		
			if($i['type']=='dir' && $i['name']!='.') { 
				$ret.='<li>
				 	<a href="./?app=files&dir='.$i['directory'].'/'.$i['name'].'" data-pathname="'.$i['directory'].'/'.$i['name'].'">'.$i['name'].'</a>'.listdir($dir.'/'.$i['name'],$dirs_stat).'
					</li>
				';
			}	
			
		}
		if($ret!=''){
			$class='class="collapsed"';
			if($dir=='' || (isset($dirs_stat[$dir]) && $dirs_stat[$dir]=='expanded'))  $class='class="expanded"';
			$ret= '<ul '.$class.' data-path="'.$dir.'"><li></li>'.$ret.'</ul>';
		}
		return $ret;
	}
}
echo listdir('',$dirs_stat);