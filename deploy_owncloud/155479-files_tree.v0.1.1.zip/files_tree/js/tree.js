/**
* ownCloud - Files Tree
*
* @author Bastien Ho (EELV - Urbancube)
* @copyleft 2012 bastienho@urbancube.fr
* @projeturl http://ecolosites.eelv.fr/files-tree
*
* Free Software under creative commons licence
* http://creativecommons.org/licenses/by-nc/3.0/
* Attribution-NonCommercial 3.0 Unported (CC BY-NC 3.0)
* 
* You are free:
* to Share — to copy, distribute and transmit the work
* to Remix — to adapt the work
*
* Under the following conditions:
* Attribution — You must attribute the work in the manner specified by the author or licensor (but not in any way that
* suggests  that they endorse you or your use of the work).
* Noncommercial — You may not use this work for commercial purposes.
*
*/
function FileTree(){
	tree=this;
	$('#fileList').parent().css('width','85%').css('float','right');
	$('#emptyfolder').css('margin-left','20%');
	$('#content').append('<div id="files_tree"><div id="dir_browser">NAVIGATION</div><div id="files_tree_switcher"></div></div>');
	$('#files_tree_switcher').click(function(){tree.toggle()});
	$('#dir_browser').css('width',$('#files_tree').width()-11).css('height',$('#files_tree').height()-40);
	tree.browse($('#dir').val());
	tree.sync();
}

FileTree.prototype={	
	toggle:function(){
		if($('#files_tree').width()==10){
			$('#fileList').parent().animate({width:'85%'},500);
			$('#files_tree').animate({width:'14%'},500);
		}
		else{
			$('#files_tree').animate({width:10},500);
			$('#fileList').parent().animate({width:$('#content').width()-11},500);
		}
	},
	sync:function(){
		if($('#fileList').parent().css('display')=='none'){
			$('#files_tree').css('display','none');
		}
		else{
			$('#files_tree').css('display','block');
		}
		setTimeout('tree.sync()',2000);
	},
	browse:function(dir){
		$.ajax({
			type: 'POST',
			//url: OC.filePath('files_tree', 'ajax', 'explore.php?dir='+dir),
			//OC.linkTo('files_tree', 'ajax/explore.php?dir='+dir),
			url:'./?app=files_tree&getfile=ajax/explore.php&dir='+dir,
			dataType: 'html',
			async: false,
			success: function (k) {
				$('#dir_browser').html(k);				
				$('#dir_browser ul ul li:first-child').click(function(){
					tree.toggle_dir($(this).parent());					
				});	
				tree.collex();	
				var lechem='';
				var la_path = $('#dir').val().split('/');
				for(var ledir in la_path){
					le_dir=la_path[ledir];
					//if(ledir=='') ledir='/';
					if(ledir>0) lechem+='/';
					lechem+=le_dir;
					console.log(lechem);
					$('ul').filterAttr('data-path', lechem).attr('class','expanded');					
					$('a').filterAttr('data-pathname', lechem).css('font-weight','700');
				}
			}
		});	
	},
	toggle_dir:function(ul){
		ul.toggleClass('expanded').toggleClass('collapsed');
		tree.collex();
		//$(this).parent().;
		$.ajax({
			type: 'POST',
			url: './?app=files_tree&getfile=ajax/save.php&d='+ul.data('path')+'&s='+ul.attr('class'),
			dataType: 'html',
			async: false,
			success: function (k) {
				//nothing to do		
			}
		});
	},
	collex:function(){
		$('ul.collapsed').children('li:first-child').stop().attr('class','c');
		$('ul.expanded').children('li:first-child').stop().attr('class','o');
	}
};

$(document).ready(function(){
  if($('#fileList').length>0) {
	var the_tree=new FileTree();
  }
});
