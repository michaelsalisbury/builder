<?php $TRANSLATIONS = array(
"Users" => "Utilisateurs",
"Name" => "Nom",
"Password" => "Mot de passe",
"Groups" => "Groupes",
"Create" => "Créer",
"Default Quota" => "Quota par défaut",
"Quota" => "Quota",
"Delete" => "Supprimer"
);