<?php

/**
 * ownCloud - internal_messages
 *
 * @author Jorge Rafael Garc�a Ramos
 * @copyright 2012 Jorge Rafael Garc�a Ramos <kadukeitor@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU AFFERO GENERAL PUBLIC LICENSE for more details.
 *
 * You should have received a copy of the GNU Affero General Public
 * License along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

class OC_INT_MESSAGES
{
    const flag_group_part = 'gp';
    const flag_group_mesg = 'gm';

    public static function delMessage ( $id , $folder )
    {
        if ($folder == 'inbox') {
            $query = OCP\DB::prepare('UPDATE *PREFIX*internal_messages SET message_delto=? WHERE message_id=?');
            $query->execute(Array(1,$id));
        }
        if ($folder == 'outbox') {
            $query = OCP\DB::prepare('UPDATE *PREFIX*internal_messages SET message_delowner=? WHERE message_id=?');
            $query->execute(Array(1,$id));
        }
    }

    public static function sendMessage ( $msgfrom , $msgto ,  $msgcontent , $msgflag='' )
    {
         if ( is_array($msgto[0]) ) {
             foreach ($msgto[0] as $user) {
                $query = OCP\DB::prepare('INSERT INTO *PREFIX*internal_messages (message_owner,message_to,message_timestamp,message_content) VALUES (?,?,?,?)');
                $query->execute(Array($msgfrom,$user,time(),$msgcontent));
            }
         }

         if ( is_array($msgto[1]) ) {
             foreach ($msgto[1] as $group) {
                $groupUsers = OC_Group::usersInGroup( $group );
                foreach ($groupUsers as $user) {
                    if ($user != $msgfrom) {
                        $query = OCP\DB::prepare('INSERT INTO *PREFIX*internal_messages (message_owner,message_to,message_timestamp,message_content,message_flag) VALUES (?,?,?,?,?)');
                        $query->execute(Array($msgfrom,$user,time(),$msgcontent,self::flag_group_part));
                    }
                }
                $query = OCP\DB::prepare('INSERT INTO *PREFIX*internal_messages (message_owner,message_to,message_timestamp,message_content,message_flag) VALUES (?,?,?,?,?)');
                $query->execute(Array($msgfrom,$group.'(group)',time(),$msgcontent, self::flag_group_mesg ));
            }
         }

         return true;
    }

    public static function unreadMessages($user)
    {
        $query  = OCP\DB::prepare('SELECT * FROM *PREFIX*internal_messages WHERE message_to = ? AND message_delto = 0 AND message_read = 0');
        $result = $query->execute(Array( $user ));
        $msgs   = $result->fetchAll();

        return count($msgs);

    }

    public static function readMessages($user)
    {
        $query  = OCP\DB::prepare('UPDATE *PREFIX*internal_messages SET message_read = 1 WHERE message_read= 0 AND message_to = ?');
        $result = $query->execute(Array( $user ));

        return 1;

    }

    public static function searchMessages ( $user , $pattern , $folder )
    {
        if ($folder == 'inbox') {
            $query  = OCP\DB::prepare('SELECT * FROM *PREFIX*internal_messages WHERE message_to = ? AND message_delto = 0 AND message_content LIKE ? ORDER by message_timestamp DESC');
            $result = $query->execute(Array( $user ,'%'.$pattern.'%'));
            $msgs   = $result->fetchAll();
        } else {
            $query  = OCP\DB::prepare('SELECT * FROM *PREFIX*internal_messages WHERE message_owner = ? AND message_delowner = 0 AND message_flag != ? AND message_content LIKE ? ORDER by message_timestamp DESC');
            $result = $query->execute(Array( $user , self::flag_group_part , '%'.$pattern.'%'));
            $msgs   = $result->fetchAll();
        }

        if ( count($msgs) ) {

                if ($folder == 'inbox') { $title  = "<p id=ubication_label>Received Messages</p>" ; } else { $title  = "<p id=ubication_label>Sent Messages</p>" ; }

                $data = $title ;
                $data.= "<table>";
                $data.= "<tbody>";

                foreach ($msgs as $message) {

                    if ($folder == 'inbox') {
                        if ($message['message_read']) { $read = "<tr class=read>"; } else { $read = "<tr class=unread>" ; }
                        $to = '' ;
                        $reply = "<a href=javascript:void(0) msg_owner=".$message['message_owner']." class=\"message_action message_reply\" original-title=Reply><img src=". OC::$WEBROOT . "/apps/internal_messages/img/reply.png></a>" ;
                    } else {
                        $read = "<tr>" ;
                        $to   = " > " . $message['message_to'] ;
                        $reply = '';
                    }

                    $date_time = OCP\Util::formatDate($message['message_timestamp']);
                    $msg_date = substr($date_time,0, ( strlen($date_time) - 7 ) );
                    $msg_time = substr($date_time,-6);

                    $data.= $read ;
                    $data.= "<td><img id=message_photo src=". OC::$WEBROOT . "/?app=user_photo&getfile=ajax%2Fshowphoto.php&user=" . $message['message_owner']."></td>" ;
                    $data.= "<td id=msg_content width=100%>";
                    $data.= "<p id=cell_user>".$message['message_owner'].$to."</p>" ;
                    $data.= "<p message_id=".$message['message_id']." name=message_content>".$message['message_content']."</p>" ;
                    $data.= "</td>";
                    $data.= "<td>" ;
                    $data.= "<p id=cell_date>". $msg_date  ."</p>" ;
                    $data.= "<p id=cell_time>". $msg_time  ."</p>" ;
                    $data.= "</td>" ;
                    $data.= "<td>" ;
                    $data.= $reply ;
                    $data.= "<a href=javascript:void(0) msg_id=".$message['message_id']." class=\"message_action message_delete\" original-title=Delete><img src=". OC::$WEBROOT . "/apps/internal_messages/img/delete.png></a>" ;
                    $data.= "</td>" ;

                    $data.= "</tr>" ;
                }
                $data.= "</tbody>";
                $data.= "</table>";

            } else {

                $data = "<p id=ubication_label>the SEARCHED text doesn't appear..</p>" ;

            }

        return  $data;

    }

    public static function folderMessages( $user , $folder)
    {
        if ($folder == 'inbox') {
            $query  = OCP\DB::prepare('SELECT * FROM *PREFIX*internal_messages WHERE message_to = ? AND message_delto = 0 ORDER by message_timestamp DESC');
            $result = $query->execute(Array( $user ));
            $msgs   = $result->fetchAll();
        } else {
            $query  = OCP\DB::prepare('SELECT * FROM *PREFIX*internal_messages WHERE message_owner = ? AND message_delowner = 0 AND message_flag != ? ORDER by message_timestamp DESC');
            $result = $query->execute(Array( $user , self::flag_group_part ));
            $msgs   = $result->fetchAll();
        }

        if ( count($msgs) ) {

                if ($folder == 'inbox') { $title  = "<p id=ubication_label>Received Messages</p>" ; } else { $title  = "<p id=ubication_label>Sent Messages</p>" ; }

                $data = $title ;
                $data.= "<table>";
                $data.= "<tbody>";

                foreach ($msgs as $message) {

                    if ($folder == 'inbox') {
                        if ($message['message_read']) { $read = "<tr class=read>"; } else { $read = "<tr class=unread>" ; }
                        $to = '' ;
                        $reply = "<a href=javascript:void(0) msg_owner=".$message['message_owner']." class=\"message_action message_reply\" original-title=Reply><img src=". OC::$WEBROOT . "/apps/internal_messages/img/reply.png></a>" ;
                    } else {
                        $read = "<tr>" ;
                        $to   = " > " . $message['message_to'] ;
                        $reply = '';
                    }

                    $date_time = OCP\Util::formatDate($message['message_timestamp']);
                    $msg_date = substr($date_time,0, ( strlen($date_time) - 7 ) );
                    $msg_time = substr($date_time,-6);

                    $data.= $read ;
                    $data.= "<td><img id=message_photo src=". OC::$WEBROOT . "/?app=user_photo&getfile=ajax%2Fshowphoto.php&user=" . $message['message_owner']."></td>" ;
                    $data.= "<td id=msg_content width=100%>";
                    $data.= "<p id=cell_user>".$message['message_owner'].$to."</p>" ;
                    $data.= "<p message_id=".$message['message_id']." name=message_content>".$message['message_content']."</p>" ;
                    $data.= "</td>";
                    $data.= "<td>" ;
                    $data.= "<p id=cell_date>". $msg_date  ."</p>" ;
                    $data.= "<p id=cell_time>". $msg_time  ."</p>" ;
                    $data.= "</td>" ;
                    $data.= "<td>" ;
                    $data.= $reply ;
                    $data.= "<a href=javascript:void(0) msg_id=".$message['message_id']." class=\"message_action message_delete\" original-title=Delete><img src=". OC::$WEBROOT . "/apps/internal_messages/img/delete.png></a>" ;
                    $data.= "</td>" ;

                    $data.= "</tr>" ;
                }
                $data.= "</tbody>";
                $data.= "</table>";

            } else {

                if ($folder == 'inbox') { $data = "<p id=ubication_label>No messages in your INBOX</p>" ; } else { $data = "<p id=ubication_label>Not outbox any message</p>" ; }

            }

        return  $data;

    }

}
