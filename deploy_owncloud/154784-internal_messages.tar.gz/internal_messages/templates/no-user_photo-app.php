<?php

echo '<ul><li class="error">';
echo $l->t('The user photo application also need to be enabled to use this application.');
echo '</li></ul>';
