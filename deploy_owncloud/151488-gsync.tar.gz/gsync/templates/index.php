<img style="display:none" id="gsync-loader" src="<?php echo image_path('gsync', 'loader.gif'); ?>" alt="" />
<div id="gsync-splash"></div>